package com.ex.moiveapp.ui.gallery;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ex.moiveapp.R;
import com.ex.moiveapp.database.ImageEntity;
import com.ex.moiveapp.database.ImageRepository;
import com.ex.moiveapp.ui.ImgDetailsActivity;

import java.util.ArrayList;
import java.util.List;

public class GalleryFragment extends Fragment {

    private RecyclerView recyclerView;
    private ImageAdapter imageAdapter;
    private ImageRepository imageRepository;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_gallery, container, false);
        recyclerView = rootView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 2));

        imageRepository = new ImageRepository(requireContext());
        imageAdapter = new ImageAdapter(new ArrayList<>());
        refreshImageRepository();
        imageAdapter.setOnItemClickListener(new ImageAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                List<ImageEntity> imageUrls = imageAdapter.getImageUrls();
                ImageEntity imageEntity = imageUrls.get(position);
                Intent intent = new Intent(requireContext(), ImgDetailsActivity.class);
                intent.putExtra("Url", imageEntity.getUrl());
                intent.putExtra("Res", imageEntity.getResourceId());
                requireActivity().startActivity(intent);
            }

            @Override
            public void onLongItemClick(int position) {
                AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
                builder.setTitle("操作").setItems(new String[]{"删除"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // 处理选项点击事件
                        imageRepository.deleteImage(imageAdapter.getImageUrls().get(position));
                        refreshImageRepository();
                    }
                });
                builder.show();
            }
        });
        recyclerView.setAdapter(imageAdapter);
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshImageRepository();
    }

    private void refreshImageRepository() {
        imageAdapter.clearData();

        imageAdapter.addData(new ArrayList<>(List.of(
                new ImageEntity(0, null, "", R.drawable.cang1),
                new ImageEntity(0, null, "", R.drawable.cang2)
        )));

        imageAdapter.addData(imageRepository.getAllImages());
    }
}