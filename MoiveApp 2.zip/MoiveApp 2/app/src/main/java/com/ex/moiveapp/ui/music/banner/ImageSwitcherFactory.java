package com.ex.moiveapp.ui.music.banner;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.ViewSwitcher;

public class ImageSwitcherFactory implements ViewSwitcher.ViewFactory {
    private Context context;

    public ImageSwitcherFactory(Context context) {
        this.context = context;
    }

    @Override
    public View makeView() {
        ImageView imageView = new ImageView(context);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        return imageView;
    }
}
