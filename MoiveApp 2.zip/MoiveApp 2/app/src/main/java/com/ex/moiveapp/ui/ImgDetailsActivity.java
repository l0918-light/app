package com.ex.moiveapp.ui;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.ex.moiveapp.R;
import com.ex.moiveapp.database.ImageEntity;
import com.ex.moiveapp.database.ImageRepository;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class ImgDetailsActivity extends AppCompatActivity {


    private static final int REQUEST_WRITE_PERMISSION = 100;
    private ImageView img;
    private ActivityResultLauncher<String> requestPermissionLauncher;

    // 创建选项数组
    private String[] options1 = {"收藏", "保存"};
    private String[] options2 = {"收藏"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_img_details);

        String imgUrl = getIntent().getStringExtra("Url");
        int res = getIntent().getIntExtra("Res", 0);

        // 初始化 Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // 设置标题
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("图片详情");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // 显示返回按钮
        }

        img = findViewById(R.id.imageView);

        if (imgUrl == null) {
            img.setImageResource(res);
        } else {
            ImageLoader.getInstance().displayImage(imgUrl, img);
        }

        //切换透明度
        seekAlpha();

        img.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                String[] options;
                if (imgUrl == null) {
                    options = options2;
                } else {
                    options = options1;
                }

                // 创建 AlertDialog
                AlertDialog.Builder builder = new AlertDialog.Builder(ImgDetailsActivity.this);
                builder.setTitle("操作").setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // 处理选项点击事件
                        switch (which) {
                            case 0:
                                // 收藏逻辑
                                ImageRepository imageRepository = new ImageRepository(ImgDetailsActivity.this);
                                if (imgUrl != null) {
                                    imageRepository.insertImage(new ImageEntity(0, imgUrl, "爱了爱了", res));
                                } else {
                                    imageRepository.insertImage(new ImageEntity(0, null, "爱了爱了",res));
                                }
                                Toast.makeText(ImgDetailsActivity.this, "收藏成功", Toast.LENGTH_SHORT).show();

                                break;
                            case 1:
                                // 保存逻辑
                                saveImageToGallery();
                                break;
                        }
                    }
                });

                // 显示 AlertDialog
                builder.show();
                return true;
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish(); // 返回上一个 Activity
        return true;
    }

    private void seekAlpha() {
        SeekBar seekBar = findViewById(R.id.seekBar);
        seekBar.setMax(255); // 设置SeekBar的最大值为255
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // 改变透明度，反向映射进度值，从255到0
                int alpha = 255 - progress;
                img.setImageAlpha(alpha);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void requestManageExternalStoragePermission() {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            intent.addCategory("android.intent.category.DEFAULT");
            intent.setData(Uri.parse(String.format("package:%s", this.getApplicationContext().getPackageName())));
            startActivityForResult(intent, 2296);
        } catch (Exception e) {
            Intent intent = new Intent();
            intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
            startActivityForResult(intent, 2296);
        }
    }

    private void saveImageToGallery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.MANAGE_EXTERNAL_STORAGE)) {
                    new AlertDialog.Builder(this).setTitle("权限请求").setMessage("我们需要管理外部存储权限来保存图片。").setPositiveButton("确定", (dialog, which) -> requestManageExternalStoragePermission()).setNegativeButton("取消", null).create().show();
                } else {
                    requestManageExternalStoragePermission();
                }
            } else {
                saveImage();

            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    new AlertDialog.Builder(this).setTitle("权限请求").setMessage("我们需要读取外部存储权限来获取您的音乐列表。").setPositiveButton("确定", (dialog, which) -> requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)).setNegativeButton("取消", null).create().show();
                } else {
                    requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            } else {
                saveImage();

            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WRITE_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            saveImage();
        } else {

            Toast.makeText(this, "需要存储权限才能保存图片", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveImage() {
        String imgUrl = getIntent().getStringExtra("Url");

        ImageLoader.getInstance().loadImage(imgUrl, new SimpleImageLoadingListener() {
            @Override
            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                File pictureFileDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MoiveApp");
                if (!pictureFileDir.exists()) {
                    pictureFileDir.mkdirs();
                }

                File pictureFile = new File(pictureFileDir, System.currentTimeMillis() + ".jpg");
                try (FileOutputStream fos = new FileOutputStream(pictureFile)) {
                    loadedImage.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                    fos.flush();
                    Toast.makeText(ImgDetailsActivity.this, "图片已保存到 " + pictureFile.getAbsolutePath(), Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(ImgDetailsActivity.this, "保存图片失败", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                Toast.makeText(ImgDetailsActivity.this, "加载图片失败", Toast.LENGTH_SHORT).show();
            }
        });
    }

}