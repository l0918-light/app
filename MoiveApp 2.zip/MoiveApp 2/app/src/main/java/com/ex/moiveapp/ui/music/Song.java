package com.ex.moiveapp.ui.music;


import java.io.Serializable;

public class Song implements Serializable {
    private long id;
    private String artist;
    private String title;
    private long duration;


    public Song(long id, String artist, String title, long duration) {
        this.id = id;
        this.artist = artist;
        this.title = title;
        this.duration = duration;
    }

    // Getters and Setters
    public long getId() {
        return id;
    }

    public String getArtist() {
        return artist;
    }

    public String getTitle() {
        return title;
    }

    public long getDuration() {
        return duration;
    }

}
