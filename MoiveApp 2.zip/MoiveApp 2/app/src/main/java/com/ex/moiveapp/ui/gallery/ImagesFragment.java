package com.ex.moiveapp.ui.gallery;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.ex.moiveapp.R;
import com.ex.moiveapp.database.ImageEntity;
import com.ex.moiveapp.ui.ImgDetailsActivity;
import com.ex.moiveapp.ui.home.ImgBean;
import com.google.gson.Gson;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ImagesFragment extends Fragment {

    private String imgType = "suiji";

    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ImageAdapter adapter;
    private boolean isLoading = false;
    private int page = 1;

    private List<ImageEntity> houseList = new ArrayList<ImageEntity>(
            List.of(
                    new ImageEntity(0, null, "", R.drawable.h1),
                    new ImageEntity(0, null, "", R.drawable.h2),
                    new ImageEntity(0, null, "", R.drawable.h3),
                    new ImageEntity(0, null, "", R.drawable.h4),
                    new ImageEntity(0, null, "", R.drawable.h5),
                    new ImageEntity(0, null, "", R.drawable.h6),
                    new ImageEntity(0, null, "", R.drawable.h7),
                    new ImageEntity(0, null, "", R.drawable.h8),
                    new ImageEntity(0, null, "", R.drawable.h9),
                    new ImageEntity(0, null, "", R.drawable.h10)
            )
    );
    private List<ImageEntity> renList = new ArrayList<ImageEntity>(
            List.of(
                    new ImageEntity(0, null, "", R.drawable.ren1),
                    new ImageEntity(0, null, "", R.drawable.ren2),
                    new ImageEntity(0, null, "", R.drawable.ren3),
                    new ImageEntity(0, null, "", R.drawable.ren4),
                    new ImageEntity(0, null, "", R.drawable.ren5),
                    new ImageEntity(0, null, "", R.drawable.ren6),
                    new ImageEntity(0, null, "", R.drawable.ren7),
                    new ImageEntity(0, null, "", R.drawable.ren8),
                    new ImageEntity(0, null, "", R.drawable.ren9),
                    new ImageEntity(0, null, "", R.drawable.ren10)
            )
    );
    private List<ImageEntity> juList = new ArrayList<ImageEntity>(
            List.of(
                    new ImageEntity(0, null, "", R.drawable.ju1),
                    new ImageEntity(0, null, "", R.drawable.ju2),
                    new ImageEntity(0, null, "", R.drawable.ju3),
                    new ImageEntity(0, null, "", R.drawable.ju4),
                    new ImageEntity(0, null, "", R.drawable.ju5),
                    new ImageEntity(0, null, "", R.drawable.ju6),
                    new ImageEntity(0, null, "", R.drawable.ju7),
                    new ImageEntity(0, null, "", R.drawable.ju8),
                    new ImageEntity(0, null, "", R.drawable.ju9),
                    new ImageEntity(0, null, "", R.drawable.ju10)
            )
    );

    private List<ImageEntity> qinList = new ArrayList<ImageEntity>(
            List.of(
                    new ImageEntity(0, null, "", R.drawable.qin1),
                    new ImageEntity(0, null, "", R.drawable.qin2),
                    new ImageEntity(0, null, "", R.drawable.qin3),
                    new ImageEntity(0, null, "", R.drawable.qin4),
                    new ImageEntity(0, null, "", R.drawable.qin5),
                    new ImageEntity(0, null, "", R.drawable.qin6),
                    new ImageEntity(0, null, "", R.drawable.qin7),
                    new ImageEntity(0, null, "", R.drawable.qin8),
                    new ImageEntity(0, null, "", R.drawable.qin9),
                    new ImageEntity(0, null, "", R.drawable.qin10)
            )
    );

    private List<ImageEntity> imageEntityList = new ArrayList<>();

    public static ImagesFragment newInstance(String type) {
        Bundle args = new Bundle();
        args.putString("type", type);
        ImagesFragment fragment = new ImagesFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imgType = getArguments().getString("type");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_images, container, false);
        swipeRefreshLayout = rootView.findViewById(R.id.swipeRefreshLayout);
        recyclerView = rootView.findViewById(R.id.recyclerView);
        setupRecyclerView();
        setupSwipeRefreshLayout();
        return rootView;
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        adapter = new ImageAdapter(new ArrayList<>());

        adapter.setOnItemClickListener(new ImageAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                List<ImageEntity> imageUrls = adapter.getImageUrls();
                ImageEntity imageEntity = imageUrls.get(position);
                Intent intent = new Intent(requireContext(), ImgDetailsActivity.class);
                intent.putExtra("Url", imageEntity.getUrl());
                intent.putExtra("Res", imageEntity.getResourceId());
                requireActivity().startActivity(intent);
            }

            @Override
            public void onLongItemClick(int position) {

            }
        });

        recyclerView.setAdapter(adapter);
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (!isLoading && !recyclerView.canScrollVertically(1)) {
                    // 上拉加载更多
                    loadMoreData();
                }
            }
        });

        refreshData();
    }

    private void setupSwipeRefreshLayout() {
        swipeRefreshLayout.setOnRefreshListener(() -> {
            // 下拉刷新
            refreshData();
        });
    }

    private void refreshData() {
        isLoading = true;
        getImg(imgType);
        new Handler().postDelayed(() -> {
            // 模拟刷新数据
            page = 1;
            adapter.clearData();
            adapter.addData(imageEntityList);
            swipeRefreshLayout.setRefreshing(false);
            isLoading = false;
        }, 2000);
    }

    private void loadMoreData() {
        isLoading = true;
        getImg(imgType);
        new Handler().postDelayed(() -> {
            // 模拟加载数据
            page++;
            adapter.addData(imageEntityList);
            isLoading = false;
        }, 2000);
    }


    /**
     * 获取接口返回的图片地址
     * <p>
     * json array 解析读取
     * <p>
     * [
     * {
     * "imgurl": "https://api.hn/dongman/6Y1bLHR1Y9ygA.jpg?t=1734335105",
     * "width": null,
     * "height": null
     * },
     * {
     * "imgurl": "https://api.hn/meizi/5a9677c8e7bce735ab45ccee.jpg?t=1734335105",
     * "width": null,
     * "height": null
     * }
     * ]
     */
    private void getImg(String imgType) {
        imageEntityList.clear();


        RequestQueue requestQueue = Volley.newRequestQueue(requireContext());
        String url = "";
        switch (imgType) {
            case "meizi":
                imageEntityList.addAll(qinList);
                url = "https://api.hn/jk.php?zd=mobile&return=jsonpro&page=" + page;
                break;
            case "dongman":
                imageEntityList.addAll(juList);

                url = "https://api.hn/acg.php?zd=mobile&return=jsonpro&page=" + page;
                break;
            case "fengjing":
                imageEntityList.addAll(renList);
                url = "https://api.hn/mc.php?zd=pc&return=jsonpro&page=" + page;
                break;
            default:
                imageEntityList.addAll(houseList);

                url = "https://api.hn/name.php?zd=mobile&return=jsonpro&page=" + page;
                break;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Gson gson = new Gson();
                Type type = new com.google.gson.reflect.TypeToken<List<ImgBean>>() {
                }.getType();
                List<ImgBean> imgBeanList = gson.fromJson(response, type);

                for (ImgBean imgBean : imgBeanList) {
                    imageEntityList.add(new ImageEntity(0, imgBean.getImgurl(), "随机壁纸", 0));
                }

            }


        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(requireActivity(), "图片获取失败", Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(stringRequest);
    }
}
