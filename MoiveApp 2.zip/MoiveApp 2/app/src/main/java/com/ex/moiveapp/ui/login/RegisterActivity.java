package com.ex.moiveapp.ui.login;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.ex.moiveapp.R;
import com.ex.moiveapp.database.UserRepository;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


         // 初始化 Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // 设置标题
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("注册");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // 显示返回按钮
        }



        EditText usernameEt = findViewById(R.id.qq_et);
        EditText passwordEt = findViewById(R.id.pwd_et);
        Button btn = findViewById(R.id.register_tv);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = usernameEt.getText().toString();
                String pwd = passwordEt.getText().toString();
                if (name.isEmpty() || pwd.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "QQ号或密码不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                UserRepository userRepository = new UserRepository(RegisterActivity.this);
                if (userRepository.getUserEntityByUsername(name) != null) {
                    Toast.makeText(RegisterActivity.this, "该QQ号已被注册", Toast.LENGTH_SHORT).show();
                    return;
                }
                long result = userRepository.insertUserEntity(name, pwd);
                if (result == -1) {
                    Toast.makeText(RegisterActivity.this, "注册失败", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(RegisterActivity.this, "注册成功", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });

    }

        @Override
    public boolean onSupportNavigateUp() {
        finish(); // 返回上一个 Activity
        return true;
    }

}