package com.ex.moiveapp.ui.launch;

import static android.content.Context.MODE_PRIVATE;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.ex.moiveapp.MainActivity;
import com.ex.moiveapp.R;
import com.ex.moiveapp.database.UserRepository;
import com.ex.moiveapp.ui.login.LoginActivity;

import java.util.ArrayList;
import java.util.List;

public class MyAdapterView extends PagerAdapter {

    private Activity activity;
    private List<View> mList = new ArrayList<>();

    public MyAdapterView(Activity activity,List<View> mList) {
        this.mList = mList;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = mList.get(position);
        if (position == 2) {
            Button btn = view.findViewById(R.id.enter_btn);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //切换存储页面的标志为false,下次进入就是i启动页
                    SharedPreferences sharedPreferences = container.getContext().getSharedPreferences(SplashActivity.SP_CONFIG, MODE_PRIVATE);
                    SharedPreferences.Editor edit = sharedPreferences.edit();
                    edit.putBoolean(SplashActivity.FIRST_ENTER, false);
                    edit.apply();

                    boolean aBoolean = sharedPreferences.getBoolean(SplashActivity.IS_LOGGED_IN, false);
                    Intent intent;
                    if (aBoolean) {
                        //跳转进入主页
                        intent = new Intent(container.getContext(), MainActivity.class);
                        container.getContext().startActivity(intent);
                    } else {
                        //跳转进入登录页
                        intent = new Intent(container.getContext(), LoginActivity.class);
                        container.getContext().startActivity(intent);
                    }
                    activity.finish();
                }
            });
        }
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }
}
