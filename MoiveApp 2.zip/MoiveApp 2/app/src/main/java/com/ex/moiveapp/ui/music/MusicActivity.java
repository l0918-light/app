package com.ex.moiveapp.ui.music;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.ex.moiveapp.R;

public class MusicActivity extends AppCompatActivity {

    private MusicService musicService;
    private boolean isBound = false;
    private SeekBar seekBar;
    private Button btnPlayPause;
    private Button btnStop;
    private TextView currentTime, totalTime;
    private boolean isPlaying = false;
    private Handler handler = new Handler();
    private Runnable updateSeekBarRunnable;

    private ImageView icon;
    private Song song;

    // Service连接
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.LocalBinder binder = (MusicService.LocalBinder) service;
            musicService = binder.getService();
            musicService.init(song.getId());
            isBound = true;

            // 设置SeekBar的最大值
            seekBar.setMax(musicService.getDuration());

            // 初始设置总时长
            updateTimeDisplay();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };
    private Animation rotation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);
        song = (Song) getIntent().getSerializableExtra("song");


        // 初始化 Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // 设置标题
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(song.getTitle());
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // 显示返回按钮
        }

        // 初始化控件
        seekBar = findViewById(R.id.seekBar);
        btnPlayPause = findViewById(R.id.btn_play_pause);
        btnStop = findViewById(R.id.btn_stop);
        currentTime = findViewById(R.id.currentTime);
        totalTime = findViewById(R.id.totalTime);


        ImageView icon = findViewById(R.id.icon);

        rotation = AnimationUtils.loadAnimation(this, R.anim.rotate);

        // 绑定Service与Activity
        Intent intent = new Intent(this, MusicService.class);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);

        // 设置SeekBar的监听器
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && isBound) {
                    musicService.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        // 设置播放/暂停按钮的点击事件
        btnPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPlaying) {
                    if (isBound) {
                        musicService.pause();
                    }
                    btnPlayPause.setText("播放");
                    icon.clearAnimation();
                    isPlaying = false;
                    stopUpdateSeekBar();
                } else {
                    if (isBound) {
                        musicService.play();
                    }
                    btnPlayPause.setText("暂停");
                    icon.startAnimation(rotation);

                    isPlaying = true;
                    startUpdateSeekBar();
                }
            }
        });

        // 设置停止按钮的点击事件
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isBound) {
                    musicService.stop();
                }
                seekBar.setProgress(0);
                btnPlayPause.setText("播放");
                icon.clearAnimation();
                isPlaying = false;
                stopUpdateSeekBar();
                currentTime.setText("00:00");
            }
        });


        // 初始化更新SeekBar的任务
        updateSeekBarRunnable = new Runnable() {
            @Override
            public void run() {
                // 判断是否已经绑定Service
                if (isBound && musicService != null && musicService.isPlaying()) {
                    seekBar.setProgress(musicService.getCurrentPosition());
                    updateTimeDisplay();
                    handler.postDelayed(this, 1000);
                }
            }
        };
    }

    // 更新当前时间和总时长
    private void updateTimeDisplay() {
        if (isBound && musicService != null) {
            int currentPosition = musicService.getCurrentPosition();
            int totalDuration = musicService.getDuration();

            String currentTimeStr = formatTime(currentPosition);
            String totalTimeStr = formatTime(totalDuration);

            currentTime.setText(currentTimeStr);
            totalTime.setText(totalTimeStr);
        }
    }

    /**
     * 格式化时间
     *
     * @param milliseconds
     * @return
     */
    private String formatTime(int milliseconds) {
        int seconds = (int) (milliseconds / 1000) % 60;
        int minutes = (int) ((milliseconds / (1000 * 60)) % 60);
        return String.format("%02d:%02d", minutes, seconds);
    }

    /**
     * 开始更新SeekBar的任务
     */
    private void startUpdateSeekBar() {
        handler.post(updateSeekBarRunnable);
    }

    /**
     * 停止更新SeekBar的任务
     */
    private void stopUpdateSeekBar() {
        handler.removeCallbacks(updateSeekBarRunnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 解绑Service
        if (isBound) {
            unbindService(serviceConnection);
            isBound = false;
        }
        // 停止更新SeekBar的任务
        stopUpdateSeekBar();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish(); // 返回上一个 Activity
        return true;
    }

}