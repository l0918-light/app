package com.ex.moiveapp.ui.music;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageSwitcher;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ex.moiveapp.R;
import com.ex.moiveapp.ui.music.banner.ImageSwitcherFactory;

import java.util.ArrayList;
import java.util.List;


public class MusicFragment extends Fragment {


    private RecyclerView recyclerView;
    private SongAdapter adapter;

    private ActivityResultLauncher<String> requestPermissionLauncher;


    private ImageSwitcher imageSwitcher;

    // 设置图片资源
    private Integer[] imageIds = {R.drawable.banner1, R.drawable.bannner2, R.drawable.bannner3, R.drawable.banner4};

    // 当前显示的图片索引
    private int currentIndex = 0;

    // 记录开始滑动时的X坐标
    private float startX = 0;

    private Handler handler = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            nextImage();
            handler.postDelayed(runnable, 3000);
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_music, container, false);

        recyclerView = rootView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireActivity()));
        adapter = new SongAdapter(new ArrayList<>());
        adapter.setOnItemClickListener(new SongAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Song song) {
                Intent intent = new Intent(requireActivity(), MusicActivity.class);
                intent.putExtra("song", song);
                requireActivity().startActivity(intent);
            }
        });
        recyclerView.setAdapter(adapter);


        imageSwitcher = rootView.findViewById(R.id.imageSwitcher);

        initView();

        return rootView;
    }

    private void initView() {

        // 注册权限请求回调
        requestPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
            if (isGranted) {
                List<Song> songs = querySongs();
                // 初始化 RecyclerView

                adapter.addSongs(songs);
            } else {
                Toast.makeText(requireActivity(), "获取存储权限被拒绝", Toast.LENGTH_SHORT).show();
            }
        });

        // 检查权限
        checkPermission();

        // 设置 ImageSwitcher 的工厂
        imageSwitcher.setFactory(new ImageSwitcherFactory(requireActivity()));
        imageSwitcher.setImageResource(imageIds[currentIndex]);

        // 添加触摸手势监听
        imageSwitcher.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // 按下时记录起始X坐标
                        startX = event.getX();
                        break;
                    case MotionEvent.ACTION_UP:
                        // 松开时比较起始和结束X坐标，判断滑动方向
                        float endX = event.getX();
                        if (endX - startX > 50) { // 左滑
                            nextImage();
                        } else if (startX - endX > 50) { // 右滑
                            previousImage();
                        }
                        break;
                }
                return true;
            }
        });

        //自动滚动
        handler.postDelayed(runnable, 3000);
    }

    // 下一张图片
    private void nextImage() {
        // 循环
        currentIndex = (currentIndex + 1) % imageIds.length;
        imageSwitcher.setImageResource(imageIds[currentIndex]);
    }

    // 上一张图片
    private void previousImage() {
        // 循环
        currentIndex = (currentIndex - 1 + imageIds.length) % imageIds.length;
        imageSwitcher.setImageResource(imageIds[currentIndex]);
    }


    /**
     * 查询音乐列表
     *
     * @return
     */

    private List<Song> querySongs() {
        List<Song> songs = new ArrayList<>();
        ContentResolver contentResolver = requireContext().getContentResolver();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.DURATION};
        Cursor cursor = contentResolver.query(uri, projection, selection, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndex(MediaStore.Audio.Media._ID));
                String artist = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
                String title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
                long duration = cursor.getLong(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));

                Song song = new Song(id, artist, title, duration);
                songs.add(song);
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }

        return songs;
    }

    private void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(requireActivity(), Manifest.permission.MANAGE_EXTERNAL_STORAGE)) {
                    new AlertDialog.Builder(requireActivity()).setTitle("权限请求").setMessage("我们需要管理外部存储权限来获取您的音乐列表。").setPositiveButton("确定", (dialog, which) -> requestManageExternalStoragePermission()).setNegativeButton("取消", null).create().show();
                } else {
                    requestManageExternalStoragePermission();
                }
            } else {
                List<Song> songs = querySongs();
                adapter.addSongs(songs);

            }
        } else {
            if (ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(requireActivity(), Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    new AlertDialog.Builder(requireActivity()).setTitle("权限请求").setMessage("我们需要读取外部存储权限来获取您的音乐列表。").setPositiveButton("确定", (dialog, which) -> requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)).setNegativeButton("取消", null).create().show();
                } else {
                    requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE);
                }
            } else {
                List<Song> songs = querySongs();
                adapter.addSongs(songs);
            }
        }
    }

    private void requestManageExternalStoragePermission() {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            intent.addCategory("android.intent.category.DEFAULT");
            intent.setData(Uri.parse(String.format("package:%s", requireActivity().getApplicationContext().getPackageName())));
            startActivityForResult(intent, 2296);
        } catch (Exception e) {
            Intent intent = new Intent();
            intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
            startActivityForResult(intent, 2296);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
    }
}