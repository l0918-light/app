package com.ex.moiveapp.ui.gallery;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ex.moiveapp.R;
import com.ex.moiveapp.database.ImageEntity;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;

import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {

    private List<ImageEntity> imageUrls;

    public interface OnItemClickListener {
        void onItemClick(int position);

        void onLongItemClick(int position);
    }

    private OnItemClickListener listener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public ImageAdapter(List<ImageEntity> imageUrls) {
        this.imageUrls = imageUrls;
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_image, parent, false);
        return new ImageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
        ImageEntity imageEntity = imageUrls.get(position);
        DisplayImageOptions options = new DisplayImageOptions.Builder()
                .cacheInMemory(true)
                .cacheOnDisk(true)
                .considerExifParams(true)
                .imageScaleType(ImageScaleType.IN_SAMPLE_POWER_OF_2)
                .build();
        if (imageEntity.getUrl() == null) {
            holder.imageView.setImageResource(imageEntity.getResourceId());
        } else {
            ImageLoader.getInstance().displayImage(imageEntity.getUrl(), holder.imageView, options);

        }
        // 绑定点击事件
        if (listener != null) {
            holder.itemView.setOnClickListener(v -> listener.onItemClick(position));
            holder.itemView.setOnLongClickListener(v -> {
                listener.onLongItemClick(position);
                return true;
            });
        }
    }

    @Override
    public int getItemCount() {
        return imageUrls.size();
    }

    static class ImageViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        ImageViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.image_view);
        }
    }

    public void addData(List<ImageEntity> newData) {
        int start = imageUrls.size();
        imageUrls.addAll(newData);
        notifyItemRangeInserted(start, newData.size());
    }

    public void clearData() {
        imageUrls.clear();
        notifyDataSetChanged();
    }

    public List<ImageEntity> getImageUrls() {
        return imageUrls;
    }
}