package com.ex.moiveapp.ui.launch;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.ex.moiveapp.MainActivity;
import com.ex.moiveapp.R;
import com.ex.moiveapp.ui.login.LoginActivity;

import java.util.ArrayList;
import java.util.List;

public class SplashActivity extends AppCompatActivity {

    private View circle_1;
    private View circle_2;
    private View circle_3;

    //SharedPreferences 文件名
    public static final String SP_CONFIG = "sp_config";
    public static final String FIRST_ENTER = "first_enter";
    public static final String IS_LOGGED_IN = "is_logged_in"; // 新增的常量

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);
        //介绍页
        FrameLayout pageContent = findViewById(R.id.page_content);
        //启动页
        FrameLayout startContent = findViewById(R.id.start_content);

        //判断是否是第一次进入
        SharedPreferences sp = getSharedPreferences(SP_CONFIG, MODE_PRIVATE);
        boolean isFirst = sp.getBoolean(FIRST_ENTER, true);

        //第一次就显示介绍页，否者显示启动页
        if (isFirst) {
            pageContent.setVisibility(View.VISIBLE);
            startContent.setVisibility(View.GONE);
        } else {
            pageContent.setVisibility(View.GONE);
            startContent.setVisibility(View.VISIBLE);

            //判断登录
            boolean aBoolean = sp.getBoolean(SplashActivity.IS_LOGGED_IN, false);

            //延迟2s后跳转
            startContent.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent;
                    if (aBoolean) {
                        //跳转进入主页
                        intent = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent);
                    } else {
                        //跳转进入登录页
                        intent = new Intent(SplashActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }

                    finish();
                }
            }, 2000);


        }

        circle_1 = findViewById(R.id.circle_1);
        circle_2 = findViewById(R.id.circle_2);
        circle_3 = findViewById(R.id.circle_3);

        //默认第一个小圆点选中
        changeDot(0);
        initPagerView();
    }

    /**
     * 初始化ViewPager和页面
     */
    private void initPagerView() {
        List<View> mList = new ArrayList<>();
        View page1 = View.inflate(this, R.layout.pager_layout1, null);
        View page2 = View.inflate(this, R.layout.pager_layout2, null);
        View page4 = View.inflate(this, R.layout.pager_layout3, null);
        mList.add(page1);
        mList.add(page2);
        mList.add(page4);

        ViewPager viewPager = findViewById(R.id.viewPager);
        MyAdapterView myAdapterView = new MyAdapterView(this,mList);
        viewPager.setAdapter(myAdapterView);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                changeDot(position);
            }

            @Override
            public void onPageSelected(int position) {
                changeDot(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    //根据选中页面切换小圆点
    private void changeDot(int index) {
        switch (index) {
            case 0:
                circle_1.setSelected(true);
                circle_2.setSelected(false);
                circle_3.setSelected(false);
                break;

            case 1:
                circle_1.setSelected(false);
                circle_2.setSelected(true);
                circle_3.setSelected(false);
                break;
            case 2:
                circle_1.setSelected(false);
                circle_2.setSelected(false);
                circle_3.setSelected(true);
                break;
            default:
                break;
        }
    }

}