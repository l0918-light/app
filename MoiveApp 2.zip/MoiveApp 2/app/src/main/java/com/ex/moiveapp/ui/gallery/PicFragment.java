package com.ex.moiveapp.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.ex.moiveapp.R;
import com.google.android.material.tabs.TabLayout;

public class PicFragment extends Fragment {
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pic, container, false);

        tabLayout = view.findViewById(R.id.tabLayout);
        viewPager = view.findViewById(R.id.viewPager);

        setupViewPager(viewPager);
        tabLayout.setupWithViewPager(viewPager);

        return view;
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());
        adapter.addFragment(new GalleryFragment(), "收藏");
        adapter.addFragment(ImagesFragment.newInstance("suiji"), "随机");
        adapter.addFragment(ImagesFragment.newInstance("meizi"), "清新");
        adapter.addFragment(ImagesFragment.newInstance("dongman"), "动漫");
        adapter.addFragment(ImagesFragment.newInstance("fengjing"), "人像");
        viewPager.setOffscreenPageLimit(5);
        viewPager.setAdapter(adapter);
    }
}