package com.ex.moiveapp.ui.login;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.ex.moiveapp.R;
import com.ex.moiveapp.database.UserEntity;
import com.ex.moiveapp.database.UserRepository;

public class ForgetActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget);
        // 初始化 Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // 设置标题
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("忘记密码");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // 显示返回按钮
        }

        EditText qqName = findViewById(R.id.qq_et);
        EditText pwd = findViewById(R.id.pwd_et);

        findViewById(R.id.btn).setOnClickListener(v -> {
            String username = qqName.getText().toString();
            String password = pwd.getText().toString();
            UserRepository userRepository = new UserRepository(this);
            if (userRepository.getUserEntityByUsername(username) == null) {
                Toast.makeText(this, "该用户不存在", Toast.LENGTH_SHORT).show();
                return;
            }

            UserEntity userEntity = userRepository.getUserEntityByUsername(username);
            userEntity.setPassword(password);
            int result = userRepository.updateUser(userEntity);
            if (result == -1) {
                Toast.makeText(this, "修改失败", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "修改成功", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish(); // 返回上一个 Activity
        return true;
    }

}