package com.ex.moiveapp.ui.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.ex.moiveapp.MainActivity;
import com.ex.moiveapp.R;
import com.ex.moiveapp.database.UserRepository;
import com.ex.moiveapp.ui.launch.SplashActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        EditText qqName = findViewById(R.id.qq_et);
        EditText pwd = findViewById(R.id.pwd_et);

        findViewById(R.id.btn).setOnClickListener(v -> {
            String username = qqName.getText().toString();
            String password = pwd.getText().toString();
            UserRepository userRepository = new UserRepository(this);
            if (userRepository.validateUser(username, password)) {
                Toast.makeText(LoginActivity.this, "登录成功", Toast.LENGTH_SHORT).show();

                SharedPreferences.Editor editor = getSharedPreferences(SplashActivity.SP_CONFIG, MODE_PRIVATE).edit();
                editor.putBoolean(SplashActivity.IS_LOGGED_IN, true);
                editor.apply();

                // 登录
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();

            } else {
                Toast.makeText(LoginActivity.this, "账号或密码错误", Toast.LENGTH_SHORT).show();
            }


        });


        TextView forgetTv = findViewById(R.id
                .forget_tv);
        forgetTv.setOnClickListener(v -> {
            // 忘记密码
            startActivity(new Intent(LoginActivity.this, ForgetActivity.class));
        });
        TextView registerTv = findViewById(R.id
                .register_tv);
        registerTv.setOnClickListener(v -> {
            // 注册
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });

    }
}