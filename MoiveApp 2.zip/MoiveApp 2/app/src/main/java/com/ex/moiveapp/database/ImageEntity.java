package com.ex.moiveapp.database;

public class ImageEntity {
    private int id;
    private String url;
    private String description;
    private Integer resourceId;

    // 构造函数、Getters 和 Setters
    public ImageEntity(int id, String url, String description, int res) {
        this.id = id;
        this.url = url;
        this.description = description;
        this.resourceId = res;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getResourceId() {
        return resourceId;
    }

    public void setResourceId(Integer resourceId) {
        this.resourceId = resourceId;
    }
}
