package com.ex.moiveapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ImageRepository {
    private DatabaseHelper dbHelper;

    public ImageRepository(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public List<ImageEntity> getAllImages() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DatabaseHelper.TABLE_IMAGES, null, null, null, null, null, null);
        List<ImageEntity> images = new ArrayList<>();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID));
            String url = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_URL));
            int res = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_RES));
            String description = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DESCRIPTION));
            images.add(new ImageEntity(id, url, description, res));
        }
        cursor.close();
        return images;
    }

    public void insertImage(ImageEntity image) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_URL, image.getUrl());
        values.put(DatabaseHelper.COLUMN_DESCRIPTION, image.getDescription());
        values.put(DatabaseHelper.COLUMN_RES, image.getResourceId());
        db.insert(DatabaseHelper.TABLE_IMAGES, null, values);
    }

    public void deleteImage(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(DatabaseHelper.TABLE_IMAGES, DatabaseHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void deleteImage(ImageEntity image) {
        deleteImage(image.getId());
    }
}
