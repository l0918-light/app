package com.ex.moiveapp.ui.music;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.provider.MediaStore;

/**
 * 提供音乐播放功能的后台服务类
 * 该服务用于播放音乐，并提供播放控制接口
 */
public class MusicService extends Service {

    // 创建一个Binder实例，用于客户端与服务之间的通信
    private final IBinder binder = new LocalBinder();
    // MediaPlayer对象，用于播放音乐
    private MediaPlayer mediaPlayer;


    /**
     * Binder类，让客户端能够访问MusicService的实例
     */
    public class LocalBinder extends Binder {
        /**
         * 获取MusicService实例
         *
         * @return MusicService实例
         */
        MusicService getService() {
            return MusicService.this;
        }
    }

    /**
     * 服务创建时调用，初始化MediaPlayer
     */
    @Override
    public void onCreate() {
        super.onCreate();
        // 初始化MediaPlayer，加载音乐文件
//        mediaPlayer = MediaPlayer.create(this, R.raw.daoxiang); // 替换为你的音频文件资源ID
        // 初始化MediaPlayer，但不加载音乐文件
    }

    public void init(long id) {
        mediaPlayer = MediaPlayer.create(this, Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, String.valueOf(id)));
    }

    /**
     * 返回Binder对象，建立客户端与服务的连接
     *
     * @param intent 客户端发送的Intent对象
     * @return IBinder对象
     */
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    /**
     * 解除客户端与服务的连接时调用
     * 停止并释放MediaPlayer资源
     *
     * @param intent 客户端发送的Intent对象
     * @return 返回false表示正常解除绑定
     */
    @Override
    public boolean onUnbind(Intent intent) {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null; // 释放后将 mediaPlayer 设为 null
        }
        return false;
    }

    /**
     * 服务销毁时调用，释放MediaPlayer资源
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null; // 释放后将 mediaPlayer 设为 null
        }
    }

    /**
     * 播放音乐
     * 如果音乐没有在播放，则开始播放
     */
    public void play() {
        if (!mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    public void playSong(Song song) {
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = MediaPlayer.create(this, Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, String.valueOf(song.getId())));
        mediaPlayer.start();
    }


    /**
     * 暂停音乐
     * 如果音乐正在播放，则暂停播放
     */
    public void pause() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    /**
     * 停止音乐播放并准备重新播放
     * 如果音乐正在播放，则停止播放并准备重新播放
     */
    public void stop() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.prepareAsync();
        }
    }

    /**
     * 获取当前音乐播放位置
     *
     * @return 当前播放位置
     */
    public int getCurrentPosition() {
        if (null != mediaPlayer) {
            return mediaPlayer.getCurrentPosition();
        }
        return 0;
    }

    /**
     * 获取音乐总时长
     *
     * @return 音乐总时长
     */
    public int getDuration() {
        if (null != mediaPlayer) {
            return mediaPlayer.getDuration();
        }
        return 0;
    }

    /**
     * 将音乐播放位置设置为指定值
     *
     * @param position 指定的播放位置
     */
    public void seekTo(int position) {
        mediaPlayer.seekTo(position);
    }

    /**
     * 检查音乐是否正在播放
     *
     * @return 如果音乐正在播放返回true，否则返回false
     */
    public boolean isPlaying() {
        return mediaPlayer.isPlaying();
    }
}
