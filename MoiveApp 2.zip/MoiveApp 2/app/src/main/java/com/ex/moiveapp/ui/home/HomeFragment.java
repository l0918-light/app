package com.ex.moiveapp.ui.home;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.ex.moiveapp.R;
import com.ex.moiveapp.database.ImageEntity;
import com.ex.moiveapp.database.ImageRepository;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;

public class HomeFragment extends Fragment {

    private static final String TAG = "HomeFragment";
    private ImageView img;
    private Button btn;
    private FloatingActionButton floatingActionButton;
    private ImageLoader imageLoader;

    private String imgUrl = "";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_home, container, false);
        img = rootView.findViewById(R.id.img);
        btn = rootView.findViewById(R.id.btn);
        floatingActionButton = rootView.findViewById(R.id.fab);
        imageLoader = ImageLoader.getInstance();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getRandoMImg();
            }
        });

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //添加图片到数据库
                if (imgUrl.isEmpty()) {
                    Toast.makeText(requireContext().getApplicationContext(), "图片地址不能为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                ImageRepository imageRepository = new ImageRepository(requireContext());
                imageRepository.insertImage(
                        new ImageEntity(0, imgUrl, "随机图片", 0)
                );
                Snackbar.make(v, "添加成功", Snackbar.LENGTH_SHORT).show();
            }
        });
        getRandoMImg();
        return rootView;
    }

    /**
     * 获取接口返回的图片地址
     */
    private void getRandoMImg() {
        RequestQueue requestQueue = Volley.newRequestQueue(requireContext());
        String url = "https://api.hn/api.php?zd=mobile&fl=fengjing&gs=json";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e(TAG, "onResponse: " + response);
                Gson gson = new Gson();
                ImgBean imgBean = gson.fromJson(response, ImgBean.class);
                imgUrl = imgBean.getImgurl();
                imageLoader.displayImage(imgBean.getImgurl(), img);
            }


        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Toast.makeText(requireContext(), "图片获取失败", Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(stringRequest);
    }
}